/**
 * ============================================================================
 * SISTEMA CRM – DATOS DE CAFETERÍA JARDINES DEL RENACER
 * Backend en Google Apps Script (Cloud Database en Google Sheets)
 * Conforme al diseño y arquitectura en Arquitectura.png y Diseño.txt
 * ============================================================================
 */

// Clave y configuración general
const CONFIG = {
  NOMBRE_APP: 'CRM DATOS DE CAFETERÍA JARDINES DEL RENACER',
  SALT_SEGURIDAD: 'RenacerCafeteria_Salt_2026',
  COL_REGISTROS: [
    'ID', 'CONSECUTIVO', 'FECHA', 'REGIONAL', 'SEDE', 'AUXILIAR',
    'FALLECIDO', 'PRESTACION', 'HORA_INGRESO', 'HORA_SALIDA',
    'TOTAL_HORAS', 'HORAS_DIURNAS', 'HORAS_NOCTURNAS', 'TURNO',
    'VALOR_DIURNO', 'VALOR_NOCTURNO', 'VALOR_A_PAGAR', 'COORDINADOR',
    'OBS_ADMON', 'USUARIO_CREADOR', 'CREADO_EL', 'ESTADO', 'MOTIVO_ANULACION'
  ]
};

/**
 * Función inicial para crear las hojas en Google Sheets con encabezados
 */
function configurarHojas() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  
  const hojasDefinicion = {
    'Registros': CONFIG.COL_REGISTROS,
    'Usuarios': ['ID', 'NOMBRE', 'CORREO', 'CELULAR', 'USUARIO', 'HASH', 'ROL', 'REGIONAL', 'SEDE', 'ESTADO', 'CREADO_EL'],
    'Tarifas': ['ID', 'ANIO', 'REGIONAL', 'SEDE', 'HORA_DIURNA', 'HORA_NOCTURNA', 'DESDE', 'HASTA', 'ESTADO'],
    'Coordinadores': ['ID', 'NOMBRES', 'APELLIDOS', 'REGIONAL', 'CELULAR', 'ACTIVO'],
    'Auxiliares': ['ID', 'NOMBRES', 'DOCUMENTO', 'TELEFONO', 'ACTIVO'],
    'Sedes': ['ID', 'REGIONAL', 'NOMBRE', 'DIRECCION', 'TELEFONO'],
    'Auditoria': ['ID', 'FECHA_HORA', 'USUARIO', 'ACCION', 'TABLA', 'REGISTRO_ID', 'DETALLE']
  };

  for (const [nombre, cols] of Object.entries(hojasDefinicion)) {
    let sheet = ss.getSheetByName(nombre);
    if (!sheet) {
      sheet = ss.insertSheet(nombre);
    }
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(cols);
      sheet.getRange(1, 1, 1, cols.length).setBackground('#1a0e2a').setFontColor('#ffffff').setFontWeight('bold');
    }
  }

  // Crear usuario Administrador inicial si no existe
  const uSheet = ss.getSheetByName('Usuarios');
  if (uSheet.getLastRow() <= 1) {
    const adminHash = generarHash('admin123');
    uSheet.appendRow([1, 'Administrador Central', 'admin@jardinesdelrenacer.com', '3100000000', 'admin', adminHash, 'ADMINISTRADOR', 'Quindío', 'Armenia', 'activo', new Date().toISOString()]);
  }

  Logger.log('Hojas configuradas correctamente en Google Sheets.');
}

/**
 * Hash simple SHA-256 en Google Apps Script
 */
function generarHash(texto) {
  const raw = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, CONFIG.SALT_SEGURIDAD + texto, Utilities.Charset.UTF_8);
  let out = '';
  for (let i = 0; i < raw.length; i++) {
    let byteVal = raw[i];
    if (byteVal < 0) byteVal += 256;
    let byteHex = byteVal.toString(16);
    if (byteHex.length === 1) byteHex = '0' + byteHex;
    out += byteHex;
  }
  return out;
}

/**
 * Punto de entrada HTTP GET
 */
function doGet(e) {
  const action = e.parameter.action;

  if (action === 'getDashboard') {
    return responderJson(obtenerEstadisticasDashboard(e.parameter));
  } else if (action === 'getRegistros') {
    return responderJson(obtenerRegistros(e.parameter));
  } else if (action === 'getTarifas') {
    return responderJson(obtenerTarifas(e.parameter));
  }

  // Por defecto retorna estado
  return HtmlService.createHtmlOutput('<h3>CRM Datos de Cafetería — API Google Apps Script Activa</h3>');
}

/**
 * Punto de entrada HTTP POST
 */
function doPost(e) {
  try {
    const postData = JSON.parse(e.postData.contents);
    const action = postData.action;

    if (action === 'login') {
      return responderJson(loginUsuario(postData));
    } else if (action === 'saveRegistro') {
      return responderJson(guardarRegistroCafeteria(postData));
    } else if (action === 'anularRegistro') {
      return responderJson(anularRegistro(postData));
    }

    return responderJson({ error: 'Acción no válida' });
  } catch (err) {
    return responderJson({ error: err.toString() });
  }
}

function responderJson(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

/**
 * Cálculo de horas diurnas y nocturnas con cruce de medianoche
 */
function calcularHorasYTurno(hInStr, hOutStr) {
  const partsIn = hInStr.split(':').map(Number);
  const partsOut = hOutStr.split(':').map(Number);
  const tIn = partsIn[0] * 60 + partsIn[1];
  const tOut = partsOut[0] * 60 + partsOut[1];

  let totalMins = tOut <= tIn ? (1440 - tIn) + tOut : tOut - tIn;
  let dayMins = 0;
  let nightMins = 0;

  let curr = tIn;
  for (let i = 0; i < totalMins; i++) {
    let mod = curr % 1440;
    if (mod >= 360 && mod < 1260) {
      dayMins++;
    } else {
      nightMins++;
    }
    curr++;
  }

  const dayHours = Math.round((dayMins / 60) * 100) / 100;
  const nightHours = Math.round((nightMins / 60) * 100) / 100;
  const totalHours = Math.round((totalMins / 60) * 100) / 100;
  let turno = 'Turno Mixto';
  if (nightHours === 0) turno = 'Turno Diurno';
  if (dayHours === 0) turno = 'Turno Nocturno';

  return { totalHours, dayHours, nightHours, turno };
}

/**
 * Login
 */
function loginUsuario(data) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName('Usuarios');
  const values = sheet.getDataRange().getValues();
  const inputHash = generarHash(data.password);

  for (let i = 1; i < values.length; i++) {
    const row = values[i];
    if ((row[4] === data.usuario || row[2] === data.usuario) && row[5] === inputHash) {
      if (row[9] !== 'activo') {
        return { success: false, error: 'Cuenta pendiente de aprobación.' };
      }
      return {
        success: true,
        user: { id: row[0], nombre: row[1], correo: row[2], rol: row[6], regional: row[7], sede: row[8] }
      };
    }
  }
  return { success: false, error: 'Credenciales inválidas.' };
}

/**
 * Guardar Registro de Cafetería en Sheet
 */
function guardarRegistroCafeteria(data) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName('Registros');
  const calc = calcularHorasYTurno(data.hora_ingreso, data.hora_salida);

  const vDiurno = (calc.dayHours * 5900);
  const vNocturno = (calc.nightHours * 7500);
  const vTotal = vDiurno + vNocturno;

  const nextId = sheet.getLastRow();
  const consecutivo = 'CAF-' + data.fecha.substring(0, 4) + '-' + ('00000' + nextId).slice(-5);

  const newRow = [
    nextId, consecutivo, data.fecha, data.regional || 'Quindío', data.sede,
    data.auxiliar_nombre, data.nombre_fallecido, data.prestacion,
    data.hora_ingreso, data.hora_salida, calc.totalHours, calc.dayHours, calc.nightHours,
    calc.turno, vDiurno, vNocturno, vTotal, data.coordinador_nombre,
    data.obs_admon || '', data.usuario_creador || 'Coordinador',
    new Date().toISOString(), 'activo', ''
  ];

  sheet.appendRow(newRow);

  // Auditoría
  const aSheet = ss.getSheetByName('Auditoria');
  aSheet.appendRow([
    aSheet.getLastRow(), new Date().toISOString(), data.usuario_creador, 'CREAR_REGISTRO', 'Registros', consecutivo, JSON.stringify({ valor: vTotal })
  ]);

  return { success: true, consecutivo: consecutivo, valor_a_pagar: vTotal };
}
